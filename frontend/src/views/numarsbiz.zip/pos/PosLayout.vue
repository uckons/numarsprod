<template>
  <div class="pos-root">
    <!-- HEADER -->
    <header class="pos-header">
      <h2>NUMARS POS</h2>

      <div class="actions">
        <button @click="$emit('new-order')">+ New Order</button>
        <button @click="$emit('open-services')">Services</button>
        <button class="logout" @click="logout">Logout</button>
      </div>
    </header>

    <!-- STATS -->
    <div class="pos-stats">
      <div class="stat">Total Today<br /><b>Rp {{ stats.total }}</b></div>
      <div class="stat">Active Orders<br /><b>{{ stats.active }}</b></div>
      <div class="stat">Revenue<br /><b>Rp {{ stats.revenue }}</b></div>
    </div>

    <!-- MAIN -->
    <main class="pos-main">
      <div style="color:red">[DEBUG SLOT OK]</div>
      <router-view />
      <!-- <slot /> -->
    </main>
  </div>
</template>

<script setup>
import { useAuthStore } from "@/store/auth.store"
import { useRouter } from "vue-router"

defineProps({
  stats: Object
})

const auth = useAuthStore()
const router = useRouter()

const logout = () => {
  auth.logout()
  router.push("/login")
}
</script>

<style scoped>
.pos-root {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #0b0b0b;
  color: white;
}

.pos-header {
  height: 56px;
  padding: 0 20px;
  background: #111;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.actions button {
  margin-left: 8px;
  padding: 6px 14px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
}

.logout {
  background: #c0392b;
  color: white;
}

.pos-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  background: #0e0e0e;
  border-bottom: 1px solid #222;
}

.stat {
  padding: 12px;
  font-size: 13px;
  color: #aaa;
}

.stat b {
  color: #c9a24d;
  font-size: 18px;
}

.pos-main {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}
</style>
