<template>
  <div class="timer-grid">
    <div
      v-for="t in timers"
      :key="t.id"
      class="timer-card"
      :class="timerClass(t.remaining)"
    >
      <div class="top">
        <span class="therapist">{{ t.therapist }}</span>
        <span class="room">Room {{ t.room }}</span>
      </div>

      <div class="time">
        {{ formatTime(t.remaining) }}
      </div>

      <div class="service">
        {{ t.service }}
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from "vue"
import api from "@/services/api"

const timers = ref([])
let interval = null

const loadTimers = async () => {
  const res = await api.get("/timers/active")
  timers.value = res.data.slice(0, 12) // 🔒 max 12 card
}

const tick = () => {
  timers.value.forEach(t => {
    if (t.remaining > 0) t.remaining--
  })
}

const timerClass = (sec) => {
  if (sec <= 600) return "danger"     // 🔴 10 menit
  if (sec <= 1800) return "warning"   // 🟡 30 menit
  return "success"                    // 🟢 60+
}

const formatTime = (sec) => {
  const m = Math.floor(sec / 60)
  const s = sec % 60
  return `${m}:${s.toString().padStart(2, "0")}`
}

onMounted(async () => {
  await loadTimers()
  interval = setInterval(tick, 1000)
})

onUnmounted(() => {
  clearInterval(interval)
})
</script>

<style scoped>
.timer-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 12px;
  margin-bottom: 16px;
}

.timer-card {
  background: linear-gradient(145deg, #0e0e0e, #151515);
  border-radius: 14px;
  padding: 12px;
  box-shadow: 0 8px 30px rgba(0,0,0,.45);
  transition: .25s;
}

.timer-card:hover {
  transform: translateY(-3px);
}

.top {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #aaa;
}

.time {
  font-size: 26px;
  font-weight: 700;
  margin: 6px 0;
}

.service {
  font-size: 12px;
  opacity: .8;
}

/* STATUS */
.success .time { color: #2ecc71 }
.warning .time { color: #f1c40f }
.danger  .time { color: #e74c3c }
</style>
