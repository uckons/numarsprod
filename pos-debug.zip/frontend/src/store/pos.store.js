import { defineStore } from "pinia"

export const usePosStore = defineStore("pos", {
  state: () => ({
    items: []
  }),

  getters: {
    total(state) {
      return state.items.reduce(
        (sum, i) => sum + i.price * i.qty,
        0
      )
    }
  },

  actions: {
    add(service) {
      console.log("STORE ADD =>", service) // ?? DEBUG

      const item = this.items.find(i => i.id === service.id)
      if (item) {
        item.qty++
      } else {
        this.items.push({
          ...service,
          qty: 1
        })
      }
    },

    remove(id) {
      this.items = this.items.filter(i => i.id !== id)
    },

    clear() {
      this.items = []
    }
  }
})
