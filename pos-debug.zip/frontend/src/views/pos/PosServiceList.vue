<template>
  <div class="service-list">
    <!-- CATEGORY TABS -->
    <div class="tabs">
      <button
        v-for="c in categories"
        :key="c"
        :class="{ active: activeCategory === c }"
        @click="activeCategory = c"
      >
        {{ c }}
      </button>
    </div>

    <!-- SERVICES GRID -->
    <div class="grid">
      <div
        v-for="s in filteredServices"
        :key="s.id"
        class="service-card"
        @click="addToCart(s)"
      >
        <div class="card-top">
          <h4>{{ s.name }}</h4>
          <span class="badge">{{ s.type }}</span>
        </div>

        <div class="card-bottom">
          <span class="duration">
            ⏱ {{ s.duration_minutes }} min
          </span>
          <strong class="price">
            Rp {{ format(s.base_price) }}
          </strong>
        </div>
      </div>

      <div v-if="!filteredServices.length" class="empty">
        No services available
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue"
import api from "@/services/api"
import { usePosStore } from "@/store/pos.store"
const pos = usePosStore()
//const emit = defineEmits(["select"])

const services = ref([])
const activeCategory = ref("ALL")

const categories = [
  "ALL",
  "SPA",
  "LC",
  "FNB",
  "KARAOKE"
]

onMounted(async () => {
  const res = await api.get("/services", {
    params: { is_active: true }
  })
  services.value = res.data.data || res.data
})

const addToCart = (service) => {
  console.log("CLICK SERVICE =>", service) // ?? DEBUG
  pos.add({
    id: service.id,
    name: service.name,
    price: service.base_price
  })
}
const filteredServices = computed(() => {
  if (activeCategory.value === "ALL") {
    return services.value
  }
  return services.value.filter(
    s => s.type === activeCategory.value
  )
})

//const select = (service) => {
//  emit("select", service)
// }
//const select = (service) => {
//  pos.add(service)
//}
//const addToCart = (service) => {
//  console.log("CLICK SERVICE:", service)
//  pos.add(service)
//}
const format = (v) =>
  Number(v || 0).toLocaleString("id-ID")
</script>

<style scoped>
.service-list {
  display: flex;
  flex-direction: column;
  height: 100%;
}

/* TABS */
.tabs {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
}

.tabs button {
  padding: 10px 18px;
  border-radius: 14px;
  border: 1px solid #222;
  background: #111;
  color: #aaa;
  font-weight: 600;
  cursor: pointer;
  transition: all .2s ease;
}

.tabs button:hover {
  color: #fff;
  border-color: #c9a24d;
}

.tabs button.active {
  background: #c9a24d;
  color: #000;
  border-color: #c9a24d;
}

/* GRID */
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 16px;
}

/* CARD */
.service-card {
  background: linear-gradient(145deg, #0e0e0e, #151515);
  border-radius: 18px;
  padding: 16px;
  box-shadow: 0 12px 35px rgba(0,0,0,.45);
  cursor: pointer;
  transition: all .25s ease;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.service-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 22px 60px rgba(0,0,0,.7);
}

.card-top h4 {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
}

.badge {
  margin-top: 6px;
  display: inline-block;
  background: rgba(201,162,77,.2);
  color: #c9a24d;
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 12px;
  width: fit-content;
}

.card-bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 14px;
}

.duration {
  font-size: 12px;
  color: #888;
}

.price {
  font-size: 16px;
  font-weight: 700;
  color: #2ecc71;
}

.empty {
  grid-column: 1 / -1;
  text-align: center;
  color: #666;
  padding: 30px;
}
</style>

