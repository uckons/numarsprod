<template>
  <div class="cart">
    <h3>🛒 Cart</h3>

    <div v-if="items.length === 0" class="empty">
      Belum ada item
    </div>

    <div
      v-for="i in items"
      :key="i.id"
      class="cart-item"
    >
      <div class="info">
        <strong>{{ i.name }}</strong>
        <small>Rp {{ format(i.base_price) }}</small>
      </div>

      <div class="qty">
        <button @click="dec(i)">−</button>
        <span>{{ i.qty }}</span>
        <button @click="inc(i)">+</button>
      </div>

      <div class="total">
        Rp {{ format(i.base_price * i.qty) }}
      </div>

      <button class="remove" @click="remove(i.id)">✕</button>
    </div>

    <div v-if="items.length" class="summary">
      <div class="row">
        <span>Total</span>
        <strong>Rp {{ format(grandTotal) }}</strong>
      </div>

      <button class="checkout">
        Bayar
      </button>

      <button class="cancel" @click="clear">
        Batalkan Order
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from "vue"
import { usePosStore } from "@/store/pos.store"
import api from "@/services/api"

const pos = usePosStore()
const items = pos.items
onMounted(async () => {
  if (!pos.orderId) {
    await pos.createOrder()
  }
})
const inc = (i) => i.qty++
const dec = (i) => {
  if (i.qty > 1) i.qty--
}

const remove = (id) => pos.remove(id)
//const clear = () => pos.clear()
const clear = async () => {
  if (!pos.orderId) {
    pos.clear()
    return
  }

  if (!confirm("Batalkan order ini?")) return

  await api.delete(`/orders/${pos.orderId}`)
  pos.clear()
}

const grandTotal = computed(() =>
  items.reduce((s, i) => s + i.base_price * i.qty, 0)
)

const format = n =>
  Number(n || 0).toLocaleString("id-ID")
</script>

<style scoped>
.cart {
  padding: 16px;
  height: 100%;
  background: #0e0e0e;
  color: #fff;
  display: flex;
  flex-direction: column;
}

.cart h3 {
  margin-bottom: 12px;
  color: #c9a24d;
}

.empty {
  color: #777;
  text-align: center;
  margin-top: 40px;
}

.cart-item {
  display: grid;
  grid-template-columns: 1fr auto auto auto;
  gap: 8px;
  padding: 10px 0;
  border-bottom: 1px solid #222;
  align-items: center;
}

.info small {
  color: #aaa;
}

.qty {
  display: flex;
  align-items: center;
  gap: 6px;
}

.qty button {
  width: 28px;
  height: 28px;
  border: none;
  background: #222;
  color: #fff;
  cursor: pointer;
}

.total {
  font-weight: bold;
  color: #c9a24d;
}

.remove {
  background: none;
  border: none;
  color: #e74c3c;
  font-size: 16px;
  cursor: pointer;
}

.summary {
  margin-top: auto;
  border-top: 1px solid #222;
  padding-top: 12px;
}

.summary .row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 12px;
}

.checkout {
  width: 100%;
  padding: 12px;
  background: #c9a24d;
  border: none;
  font-weight: bold;
  cursor: pointer;
}

.cancel {
  margin-top: 8px;
  width: 100%;
  padding: 10px;
  background: #333;
  color: #fff;
  border: none;
  cursor: pointer;
}
</style>
