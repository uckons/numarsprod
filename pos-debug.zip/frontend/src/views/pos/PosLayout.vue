<template>
  <div class="pos-layout">
    <header class="pos-header">
      <h2>NUMARS POS</h2>

      <div class="right">
        <span>{{ user.username }} (Kasir)</span>
        <button @click="logout">Logout</button>
      </div>
    </header>

    <main class="pos-main">
      <slot />
    </main>
  </div>
</template>

<script setup>
import { useAuthStore } from "@/store/auth.store"
import { useRouter } from "vue-router"

const auth = useAuthStore()
const router = useRouter()
const user = auth.user

const logout = () => {
  auth.logout()
  router.push("/login")
}
</script>

<style scoped>
.pos-layout {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #0b0b0b;
  color: white;
}
.pos-header {
  height: 56px;
  padding: 0 20px;
  background: #111;
  border-bottom: 1px solid #222;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.pos-main {
  flex: 1;
  overflow: hidden;
}
button {
  background: #c0392b;
  border: none;
  color: white;
  padding: 6px 14px;
  border-radius: 8px;
}
</style>
